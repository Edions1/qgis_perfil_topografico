from qgis.PyQt.QtWidgets import QAction
from qgis.core import QgsProject, QgsMapLayer, QgsRaster

from .tool import ClickAltitudeTool
from .plotter import ProfilePlotter


class PerfilTopograficoPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.canvas = iface.mapCanvas()

        self.action = None
        self.tool = None
        self.plotter = None

    def initGui(self):
        self.action = QAction("Perfil Topográfico 3D", self.iface.mainWindow())
        self.action.triggered.connect(self.run)

        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Perfil Topográfico", self.action)

    def unload(self):
        self.iface.removeToolBarIcon(self.action)
        self.iface.removePluginMenu("&Perfil Topográfico", self.action)

    def run(self):
        raster = self.get_dem()

        self.plotter = ProfilePlotter()
        self.tool = ClickAltitudeTool(self.canvas, raster, self.plotter)

        self.canvas.setMapTool(self.tool)

    # =====================================================
    # 🔍 NOVO GET DEM ROBUSTO
    # =====================================================
    def get_dem(self):
        layers = list(QgsProject.instance().mapLayers().values())

        # 1️⃣ Raster selecionado
        selected = self.iface.layerTreeView().selectedLayers()
        for layer in selected:
            if self.is_valid_dem(layer):
                return layer

        # 2️⃣ Raster visível
        root = self.iface.layerTreeCanvasBridge().rootGroup()
        for layer in layers:
            node = root.findLayer(layer.id())
            if node and node.isVisible():
                if self.is_valid_dem(layer):
                    return layer

        # 3️⃣ Qualquer raster válido
        for layer in layers:
            if self.is_valid_dem(layer):
                return layer

        raise Exception("Nenhum DEM válido encontrado!")

    # =====================================================
    # 🔎 VALIDADOR DE DEM
    # =====================================================
    def is_valid_dem(self, layer):

        if layer.type() != QgsMapLayer.RasterLayer:
            return False

        provider = layer.dataProvider()

        try:
            extent = layer.extent()
            point = extent.center()

            ident = provider.identify(point, QgsRaster.IdentifyFormatValue)

            if not ident.isValid():
                return False

            results = ident.results()
            if not results:
                return False

            val = next(iter(results.values()))

            if val is None:
                return False

            if isinstance(val, (int, float)):
                return True

        except Exception:
            return False

        return False
