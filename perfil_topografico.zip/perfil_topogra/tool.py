from qgis.gui import QgsMapToolEmitPoint, QgsRubberBand
from qgis.core import (
    QgsProject,
    QgsCoordinateTransform,
    QgsDistanceArea,
    QgsWkbTypes,
    QgsRaster
)

from PyQt5.QtGui import QColor


class ClickAltitudeTool(QgsMapToolEmitPoint):

    def __init__(self, canvas, raster, plotter):
        super().__init__(canvas)

        self.canvas = canvas
        self.raster = raster
        self.plotter = plotter

        self.prev_point = None
        self.prev_alt = None
        self.total_dist = 0

        self.profile_data = {
            "x": [],
            "y": [],
            "dist": [],
            "alt": []
        }

        self.rubber = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.rubber.setColor(QColor(0, 255, 65))
        self.rubber.setWidth(2)

        self.dist_calc = QgsDistanceArea()
        self.dist_calc.setSourceCrs(
            QgsProject.instance().crs(),
            QgsProject.instance().transformContext()
        )
        self.dist_calc.setEllipsoid("WGS84")

        self.transform = QgsCoordinateTransform(
            self.canvas.mapSettings().destinationCrs(),
            QgsProject.instance().crs(),
            QgsProject.instance()
        )

    def reset(self):
        self.prev_point = None
        self.prev_alt = None
        self.total_dist = 0

        for k in self.profile_data:
            self.profile_data[k].clear()

        self.rubber.reset(QgsWkbTypes.LineGeometry)
        self.plotter.reset()

        print("🔄 Reset")

    def get_altitude(self, point):
        ident = self.raster.dataProvider().identify(
            point,
            QgsRaster.IdentifyFormatValue
        )
        if ident.isValid():
            res = ident.results()
            if res:
                return next(iter(res.values()))
        return None

    def canvasPressEvent(self, event):
        if event.button() == 2:
            self.reset()

    def canvasReleaseEvent(self, event):
        point = self.toMapCoordinates(event.pos())
        point_proj = self.transform.transform(point)

        altitude = self.get_altitude(point)
        if altitude is None:
            return

        if self.prev_point is None:
            self.prev_point = point_proj
            self.prev_alt = altitude

            self.profile_data["x"].append(point_proj.x())
            self.profile_data["y"].append(point_proj.y())
            self.profile_data["dist"].append(0)
            self.profile_data["alt"].append(altitude)

            self.rubber.addPoint(point)
            self.plotter.update(self.profile_data)
            return

        dist = self.dist_calc.measureLine(self.prev_point, point_proj)
        self.total_dist += dist

        self.profile_data["x"].append(point_proj.x())
        self.profile_data["y"].append(point_proj.y())
        self.profile_data["dist"].append(self.total_dist)
        self.profile_data["alt"].append(altitude)

        self.rubber.addPoint(point)
        self.plotter.update(self.profile_data)

        self.prev_point = point_proj
        self.prev_alt = altitude
