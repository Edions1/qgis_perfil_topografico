import matplotlib.pyplot as plt
import numpy as np

plt.style.use('dark_background')

plt.rcParams.update({
    "figure.facecolor": "#000000",
    "axes.edgecolor": "#00ff41",
    "axes.labelcolor": "#00ff41",
    "xtick.color": "#00ff41",
    "ytick.color": "#00ff41",
    "grid.color": "#003b00",
})


class ProfilePlotter:

    def __init__(self):
        plt.ion()
        self.fig = plt.figure(figsize=(12, 10))

        self.ax_map = self.fig.add_subplot(2, 2, 1)
        self.ax_prof = self.fig.add_subplot(2, 2, 2)
        self.ax_slope = self.fig.add_subplot(2, 2, 3)
        self.ax_3d = self.fig.add_subplot(2, 2, 4, projection='3d')

    def reset(self):
        self.fig.clf()

    def update(self, data):
        green = "#00ff41"

        # MAPA
        self.ax_map.clear()
        self.ax_map.set_title("Trajeto XY")
        self.ax_map.grid(True)
        self.ax_map.plot(data["x"], data["y"], color=green, marker="o")

        # PERFIL
        self.ax_prof.clear()
        self.ax_prof.set_title("Perfil")
        self.ax_prof.grid(True)
        self.ax_prof.plot(data["dist"], data["alt"], color=green, marker="o")

        # SLOPE
        slopes = []
        sx = []

        for i in range(1, len(data["alt"])):
            dz = data["alt"][i] - data["alt"][i - 1]
            dx = data["dist"][i] - data["dist"][i - 1]
            slope = (dz / dx) * 100 if dx != 0 else 0

            slopes.append(slope)
            sx.append(data["dist"][i])

        self.ax_slope.clear()
        self.ax_slope.set_title("Inclinação (%)")
        self.ax_slope.grid(True)
        self.ax_slope.plot(sx, slopes, color=green, marker="o")

        # 3D
        self.ax_3d.clear()
        self.ax_3d.set_title("3D")

        if len(data["alt"]) > 3:
            x = np.array(data["dist"])
            z = np.array(data["alt"])
            y = np.linspace(0, 1, len(x))

            X, Y = np.meshgrid(x, y)
            Z = np.tile(z, (len(y), 1))

            self.ax_3d.plot_surface(X, Y, Z, cmap='Greens')

        plt.tight_layout()
        plt.draw()
        plt.pause(0.01)
